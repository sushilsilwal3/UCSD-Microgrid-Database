clc;close all;clear all;
%% data range defining
start_time=datetime('2019-05-01 00:00:00');
end_time=datetime('2019-07-31 23:45:00');


%% This code take raw data input, fills missing or incorrect data, and saves the processed data in another folder
data_input='C:\Users\sushi\OneDrive\Desktop\Final data files\Building Loads\CenterHall.csv'; %folder where raw data csv files are kept

%% Initialize variables.
filename = fullfile(data_input);
delimiter = ',';
startRow = 2;
%% Format for each line of text:
formatSpec = '%s%f%f%*s%*s%*s%*s%*s%*s%[^\n\r]';
%% Open the text file.
fileID = fopen(filename,'r','n','UTF-8');
% Skip the BOM (Byte Order Mark).
fseek(fileID, 3, 'bof');
%% Read columns of data according to the format.
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string', 'EmptyValue', NaN, 'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
%% Create output variable
data_in = table(dataArray{1:end-2}, 'VariableNames',{'date_time','real'});
%% reverse the time order of the data
data_in=flip(data_in);
data_in.date_time=datetime(data_in.date_time);

%% select thd data range
n1=find(data_in.date_time==start_time);
n2=find(data_in.date_time==end_time);
data_in=data_in(n1:n2,:);
%% Find and add missing data point with zero data
time_all = (datetime(data_in.date_time(1)):minutes(15):datetime(data_in.date_time(end)))';
time_miss=setdiff(time_all, datetime(data_in.date_time));

for j=1:length(time_miss)
    missed=datetime(time_miss(j));
    t_minus15=datetime(missed-minutes(15)); %time 15 min before the missing data
    t_pos=find(data_in.date_time==t_minus15);  %position just before the missing point
    missed.Format='yyyy-MM-dd HH:mm:ss';
    data_in=[data_in(1:t_pos,:);{missed 0};data_in((t_pos+1):end,:)];
end

%% Replace zero data with suitable data replacing logic
Real_power=data_in.real;
%% replacing missing data and zero data
j=1;
for j=1:length(Real_power)
    if j==1
        continue
    end
    if Real_power(j)<1
        if j<=672  %first week
            Real_power(j)=Real_power(j-1); % for two days, data is replaced by the previous data point
        else
            sim_day=1; %finding nearest similar day
            while isbusday(data_in.date_time(j))~=isbusday(data_in.date_time((j-96*sim_day)))
                sim_day=sim_day+1;
                if sim_day>7
                    break
                end
            end
            Real_power(j)=Real_power(j-96*sim_day);
        end
        
    end
end
%% Smooth the data and find astray point and replace with same logic
Real_power_smooth=smoothdata(Real_power,'gaussian',10);
mean_real=mean(Real_power);
j=1;
jj=1;
cor_real=[];
cor_reac=[];
corrected_real={};
for j=1:length(Real_power)
    if j==1
        continue
    end
    if abs(Real_power(j)-Real_power_smooth(j))>0.5*mean_real
        cor_real(jj)=data_in.real(j);
        real_date(jj)=data_in.date_time(j);
        jj=jj+1;
        if j<=672  %first two days
            Real_power(j)=Real_power(j-1); % for two days, data is replaced by the previous data point
        else
            sim_day=1; %finding nearest similar day
            while isbusday(data_in.date_time(j))~=isbusday(data_in.date_time((j-96*sim_day)))
                sim_day=sim_day+1;
                if sim_day>7
                    break
                end
            end
            Real_power(j)=Real_power(j-96*sim_day);
        end
    end
end
%% update data in process with corrected data
data_in.real=Real_power(:);

%% visualizing the data plots
time_array=data_in.date_time(:);
figure, plot(time_array,Real_power,'b');title('Real power')

%% Close the text file.
fclose(fileID);

%% write in the text file
writetable(data_in, 'processed_data') %

%% Clear temporary variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

toc